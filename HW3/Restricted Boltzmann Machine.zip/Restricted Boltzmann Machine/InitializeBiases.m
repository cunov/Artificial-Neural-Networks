function biasH = InitializeBiases(numNeurons)
    biasH = -1 + 2*rand(1,numNeurons);
end


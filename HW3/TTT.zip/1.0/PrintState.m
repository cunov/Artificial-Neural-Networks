function [] = PrintState(boardState)
%UNTITLED5 Summary of this function goes here
%   Detailed explanation goes here

disp(boardState)
end


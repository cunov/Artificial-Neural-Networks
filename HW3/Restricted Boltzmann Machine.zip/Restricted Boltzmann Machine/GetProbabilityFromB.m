function p = GetProbabilityFromB(b)
    p = 1/(1+exp(-2*b));
end


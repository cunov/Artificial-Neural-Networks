function theta = InitializeThresholds(numHidden)
theta = -1 + 2*rand(1,numHidden);
end

